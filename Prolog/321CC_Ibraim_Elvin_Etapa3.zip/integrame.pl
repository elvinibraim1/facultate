:- ensure_loaded('checker.pl').

%test_mode(detailed).

% Considerăm următoarele reprezentări:
%
% O integramă este reprezentată prin structura (compusul)
% integ(H, W, Lista, Vocab), unde:
% H este înălțimea integramei
% W este lățimea integramei
% Lista este o listă de tupluri (Poz, Valoare), unde
%   Poz este un tuplu (R, C) conținând rândul și coloana (0-based)
%   Valoare este una dintre:
%     x - dacă celula este neagră (nu poate fi completată cu litere)
%     o literă, dacă celula este completată cu o literă
%     o listă de întrebări, reprezentate ca tupluri (Text, Dir, ID), cu
%       Text - un literal, textul întrebării
%       Dir - una dintre valorile j sau d, indicând direcția întrebării
%       ID - un identificator numeric al întrebării
% Vocab este o listă de literali reprezentând cuvinte disponibile
% pentru a rezolva întrebarea.
%
% În ieșirea predicatului intrebări, o întrebare este reprezentată ca
% ((R, C), Text, Dir, ID), unde
% R este rândul căsuței cu întrebarea (0-based)
% C este coloana căsuței cu întrebarea (0-based)
% Text este textul întrebării (un literal)
% Dir este j sau d, reprezentând direcția în care trebuie să fie plasat
% răspunsul (jos sau dreapta)
% ID este un identificator numeric al întrebării.

% Puteți vizualiza integramele cu:
% integrama(0, W), print_integrama(W).
% integrama(1, W), print_integrama(W).
% integrama(2, W), print_integrama(W).
% integrama(3, W), print_integrama(W).
%
% Testați cu
% vmtest.
% Testați teste individuale (vedeți predicatul tt din checker.pl) cu
% vmtest(Test).
% de exemplu cu vmtest(intrebari).


% intrebari/2
% intrebari(integ(+H, +W, +Lista, +Vocab), -Lista_intrebari)
% Este adevărat atunci când Lista_intrebari este o lista de tupluri
% ((R, C), Text, Dir, ID), fiecare tuplu corespunzând unei întrebări din
% integramă (rândul, coloana, textul întrebării, direcția (j/d),
% identificatorul).
%
% BONUS: intrebari are o singură soluție (o singură listă) pentru o
% anumită integramă.
intrebari(integ(_, _, [], _), []).
intrebari(integ(_, _, [Hlist | Tlist], _), [((X, Y), (Intrebare, Directie, ID)) | Lista_intrebari]) :-
                Hlist = ((X, Y),[(Intrebare, Directie, ID)]),
                intrebari(integ(_, _, Tlist, _), Lista_intrebari),!.
intrebari(integ(_, _, [Hlist | Tlist], _), [((X, Y), (Intrebare, Directie, ID)), ((X, Y), (Intrebare2, Directie2, ID2))| Lista_intrebari]) :-
                Hlist = ((X, Y),[(Intrebare, Directie, ID), (Intrebare2, Directie2, ID2)]),
                intrebari(integ(_, _, Tlist, _), Lista_intrebari),!.
intrebari(integ(_, _, [Hlist | Tlist], _), Lista_intrebari) :-
                Hlist = ((_, _), _),
                intrebari(integ(_, _, Tlist, _), Lista_intrebari),!.
intrebari(integ(_, _, [Hlist | Tlist], _), Lista_intrebari) :-
                Hlist = [_ | _],
                intrebari(integ(_, _, Tlist, _), Lista_intrebari),!.

% id_intrebare/2
% id_intrebare(+Integ, ?Intrebare, ?Q_ID)
% Este adevărat dacă în integrama reprezentată ca integ(...), Intrebare
% este un text iar Q_ID este un identificator care corespund aceleași
% întrebări.
id_intrebare(integ(_, _, [], _), _, _).
id_intrebare(integ(_, _, [Hlist | Tlist], _), Intrebare, Q_ID) :- Hlist = ((_,_ ),[(Intr,_ , ID)]),
                Intrebare = Intr, Q_ID = ID,
                id_intrebare(integ(_, _, Tlist, _), Intrebare, Q_ID),!.
id_intrebare(integ(_, _, [Hlist | Tlist], _), Intrebare, Q_ID) :- Hlist = ((_,_ ),[(Intr,_ , ID), (_, _, _)]),
                Intrebare = Intr, Q_ID = ID,
                id_intrebare(integ(_, _, Tlist, _), Intrebare, Q_ID),!.
id_intrebare(integ(_, _, [Hlist | Tlist], _), Intrebare, Q_ID) :- Hlist = ((_,_ ),[(_,_ , _), (Intr2, _, ID2)]),
                Intrebare = Intr2, Q_ID = ID2,
                id_intrebare(integ(_, _, Tlist, _), Intrebare, Q_ID),!.
id_intrebare(integ(_, _, [Hlist | Tlist], _), Intrebare, Q_ID) :- Hlist = ((_, _), _),
                id_intrebare(integ(_, _, Tlist, _), Intrebare, Q_ID),!.
id_intrebare(integ(_, _, [Hlist | Tlist], _), Intrebare, Q_ID) :- Hlist = [_ | _],
                id_intrebare(integ(_, _, Tlist, _), Intrebare, Q_ID),!.

% completare/3
% completare(+Integ, +Sol, -Integrama)
% Predicatul produce Integrama, o structură de forma integ(...),
% pornind de la Integ, în care au fost completate celule conform cu
% soluția Sol.
% Soluția este reprezentată ca o listă de perechi (Întrebare, Răspuns),
% unde Întrebarea este textul unei întrebări, iar Răspuns este un cuvânt
% de completat; ambele sunt atomi (literali).
% De exemplu, o soluție parțială pentru integrama 0 poate fi:
% [('Din care plouă', 'NOR'), ('Al doilea număr', 'DOI')]
%
% BONUS: lungime_spatiu are o singură soluție pentru o anumită
% întrebare.
% Puteți testa manual predicatul cu o interogare de forma:
% integrama(0, W), solutie(0, Sol), completare(W, Sol, W2),
%   print_integrama(W2).
completare_aux(_, [], _, (_, _, _)).
completare_aux(W, [((X, Y), _ , Dir, ID) | _], ID, (X, Y, Dir)) :-
        completare_aux(W, [], ID, (X, Y, Dir)), !.
completare_aux(W, [ _ | Lista_intrebari], ID, (X, Y, Dir)) :-
        completare_aux(W, Lista_intrebari, ID, (X, Y, Dir)), !.

completare_aux3( _, [], ACC,  ACC) :- !.
completare_aux3((X, Y, 'j') , [H | T], ACC, Listfin) :-
        X1 is X + 1,
        completare_aux3((X1, Y, 'j') ,  T,  [((X1, Y), H) |ACC] , Listfin), !.
completare_aux3((X, Y, 'd') , [H | T], ACC, Listfin) :-
        Y1 is Y + 1,
        completare_aux3((X, Y1, 'd') ,  T,  [((X, Y1), H) |ACC] , Listfin), !.

completare(integ(_, _, List, _), [], integ(_, _, List2, _)):- sort(List, List2).
completare(integ(X, Y, List, Abec), [(Intrebare, Solutie) | Tsol], integ(X, Y, List3, Abec)) :-
           intrebari(integ(_, _, List, _), Q),
           id_intrebare(integ(_, _, List, _), Intrebare, ID),
           completare_aux(integ(_, _, List, _), Q, ID, Z),
           atom_chars(Solutie, L),
           completare_aux3(Z, L, [], ListToAppend),
           append(List, ListToAppend, List2),

           completare(integ(X, Y, List2, Abec), Tsol, integ(X, Y, List3, Abec)), !.

% lungime_spatiu/3
% lungime_spatiu(integ(+H, +W, +Lista, +Vocab), +Intrebare, -Lungime)
% pentru Bonus:
% lungime_spatiu(integ(+H, +W, +Lista, +Vocab), ?Intrebare, ?Lungime)
%
% Returnează lungimea spațiului asociat întrebării date.
% Întrebarea este indicată prin textul ei. De exemplu:
% lungime_spatiu pentru integrama 0 și întrebarea 'Al doilea număr'
% trebuie să lege Lungime la 3.
%
% BONUS: lungime_spatiu are o singură soluție pentru o anumită
% întrebare.
% Puteți testa manual predicatul cu o interogare de forma:
% integrama(0, W), id_intrebare(W, Text, 3), lungime_spatiu(W, Text, X).
lungime_spatiu(integ(_, _, List, _), Intrebare, Lungime) :-
        intrebari(integ(_, _, List, _), Q),
        id_intrebare(integ(_, _, List, _), Intrebare, ID),
        completare_aux(integ(_, _, List, _), Q, ID, Z),
        Z = (X, Y, 'j'),
        findall(P, (member(P, List), P = ((_, Y), _)), SameCollumn),
        lungime_spatiu_aux(SameCollumn, Z, L),
        Lungime is L - X - 1,!.

lungime_spatiu(integ(_, _, List, _), Intrebare, Lungime) :-
        intrebari(integ(_, _, List, _), Q),
        id_intrebare(integ(_, _, List, _), Intrebare, ID),
        completare_aux(integ(_, _, List, _), Q, ID, Z),
        Z = (X, Y, 'd'),
        findall(P, (member(P, List), P = ((X, _), _)), SameRow),
        lungime_spatiu_aux(SameRow, Z, L),
        Lungime is L - Y - 1 ,!.


lungime_spatiu_aux([], (X1, _, _), X1).
lungime_spatiu_aux(List, (X, Y, 'j'), Lungime) :-
        X1 is X + 1,
        member(((X1, Y), _), List),
        lungime_spatiu_aux([], (X1, Y, _), Lungime).
lungime_spatiu_aux(List, (X, Y, 'j'), Lungime) :-
        X1 is X + 1,
        not(member(((X1, Y), _), List)),
        lungime_spatiu_aux(List, (X1, Y, _), Lungime).
lungime_spatiu_aux(List, (X, Y, 'd'), Lungime) :-
        Y1 is Y + 1,
        member(((X, Y1), _), List),
        lungime_spatiu_aux([], (Y1, Y1, 'd'), Lungime).
lungime_spatiu_aux(List, (X, Y, 'd'), Lungime) :-
        Y1 is Y + 1,
        not(member(((X, Y1), _), List)),
        lungime_spatiu_aux(List, (X, Y1, 'd'), Lungime).

% intersectie/5
% intersectie(integ(+H, +W, +Lista, +Voc), +I1, -Poz1, +I2, -Poz2)
% pentru Bonus:
% intersectie(integ(+H, +W, +Lista, +Voc), ?I1, ?Poz1, ?I2, ?Poz2)
%
% Pentru o integramă și două întrebări date prin textul lor (I1 și I2),
% al căror răspunsuri se intersectează, întoarce în Poz1 indicele din
% răspunsul la I1 la care este intersecția, și în Poz2 indicele din
% răspunsul la I2 la care este intersecția. Indecșii incep de la 0.
%
% De exemplu, în integrama 0:
%  █       █       2↓      3↓      █
%  █       0↓,1→   -       -       █
%  4→      -       -       -       █
%  5→      -       -       -       █
%  █       █       █       █       █
%
%  Întrebările 'Primii 3 din artă' și 'Afirmativ' (3, respectiv 1) se
%  intersectează la pozițiile 0, respectiv 2 (va fi litera A, de la
%  ART, respectiv DA).

intersectie(W, I1, Poz1, I2, Poz2) :-
        id_intrebare(W, I1, ID1), 
        id_intrebare(W, I2, ID2),
        intrebari(W, Q),
        completare_aux(W, Q, ID1, (X1, Y1, Dir1)), %%indicii de la care pleaca intrebarile
        Dir1 = 'j',
        completare_aux(w, Q, ID2, (X2, Y2, Dir2)),
        Dir2 = 'd',
        X2 - X1 - 1 >= 0,
        Y1 - Y2 - 1 >= 0,
        Poz1 is X2 - X1 - 1,
        Poz2 is Y1 - Y2 - 1.

intersectie(W, I1, Poz1, I2, Poz2) :-
        id_intrebare(W, I1, ID1), 
        id_intrebare(W, I2, ID2),
        intrebari(W, Q),
        completare_aux(W, Q, ID1, (X1, Y1, Dir1)), %%indicii de la care pleaca intrebarile
        Dir1 = 'd',
        completare_aux(w, Q, ID2, (X2, Y2, Dir2)),
        Dir2 = 'j',
        X1 - X2 - 1 >= 0,
        Y2 - Y1 - 1 >= 0,
        Poz2 is X1 - X2 - 1,
        Poz1 is Y2 - Y1 - 1.

% solutii_posibile/2
% solutii_posibile(integ(+H, +W, +Lista, +Vocabular), -Solutii)
% Formează o listă Solutii, conținând perechi de forma
% (Întrebare, Cuvinte), unde
% Întrebare este textul unei întrebări din integramă, iar Cuvinte este o
% listă de cuvinte sunt din Vocabular și au lungimea corectă pentru a fi
% răspuns la întrebare. Solutii conține câte o pereche pentru fiecare
% întrebare din integramă.
% Cuvintele sunt reprezentate ca liste de atomi, fiecare atom
% având lungime 1 (o singură literă).
% De exemplu, pentru integrama 0, Solutii conține 6 perechi, două dintre
% ele fiind:
% ('Afirmativ', [['D', 'A'], ['N', 'U']])
% ('Din care plouă',
% [['N','O','R'],['A','R','T'],['U','I','T'],['D','O','I']]).

list([], _, Acc, Acc) :- !.
list([H | Vocab], Lungime_sol, Acc, List):-
        atom_chars(H, L),
        length(L, Lungime_sol),
        list(Vocab, Lungime_sol, [L | Acc], List), !.
list([_ | Vocab], Lungime_sol, Acc, List):-
        list(Vocab, Lungime_sol, Acc, List), !.

sol(_, [], Acc, Acc) :- !.
sol(integ(_, _, Lista, Vocab), [H | Q], Acc, Sol) :-
        H = ((X, Y), I, Dir, ID),
        lungime_spatiu(integ(_, _, Lista, Vocab), ((X, Y), I, Dir, ID), Lungime),
        list(Vocab, Lungime, [], List),
        sol(integ(_,_, Lista, Vocab), Q, [(I, List) | Acc], Sol).
        
solutii_posibile(integ(_, _, Lista, Vocab), Sol) :-
                intrebari(integ(_, _, Lista, _), Q),
                sol(integ(_, _, Lista, Vocab), Q, [], Sol).

% rezolvare/2
% rezolvare(+Integ, -Solutie)
% Rezolvare produce în Solutie soluția integramei Integ. Soluția este
% reprezentată ca o listă de perechi de literali, fiecare pereche
% conținând textul unei întrebări și cuvântul (ca literal) care este
% răspunsul la întrebare.
%
% BONUS: rezolvare nu oferă soluții duplicate - numărul de soluții ale 
% predicatului este chiar numărul de completări posibile ale integramei.
rezolvare(_, _) :- false.
